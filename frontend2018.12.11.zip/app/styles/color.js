export const color = {
    warning: '#ff1111',
    active: '#00C853',
    highlight: '#00E5FF',
}