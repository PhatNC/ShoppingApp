import { all } from 'redux-saga/effects'
import appSaga from './containers/App/saga';
import topProductSaga from './containers/Home/TopProduct/saga';
import cartSaga from './containers/CartScreen/saga';
import searchProductSaga from './containers/SeachView/saga';
// import newProductSaga from './containers/Tinder/saga';

export default function* sagas() {
  yield all([
    ...appSaga,
    ...topProductSaga,
    ...cartSaga,
    ...searchProductSaga,
    // ...newProductSaga
  ]);
}
