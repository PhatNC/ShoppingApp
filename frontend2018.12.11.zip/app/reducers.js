import { combineReducers } from 'redux-immutable';

import AppReducer from './containers/App/reducer';
import TopProductReducer from './containers/Home/TopProduct/reducer';
import CartReducer from './containers/CartScreen/reducer';
import SearchReducer from './containers/SeachView/reducer';
// import NewProductReducer from './containers/Tinder/reducer';


export default combineReducers({
  AppReducer: AppReducer,
  TopProductReducer: TopProductReducer,
  CartReducer: CartReducer,
  SearchReducer: SearchReducer,
  // NewProductReducer: NewProductReducer,
});
