// import { createSelector } from 'reselect';


// const listProductReducer = (state) => {
//   // console.log(state)
//   return state.get('ListProductReducer');
// };
// // const appReducer = (state) => state.AppReducer;

// const selectProducts = () => createSelector(
//   listProductReducer,
//   (substate) => substate.get('products').toJS()
// );


// export {
//   listProductReducer,
//   selectProducts,
// };
