// export const SCREEN_NAME = 'GET_PRODUCT';

// export const GET_PRODUCT_PATH = '/product';

// // _____________________________________________________________________________
// //                                                                  GET_PRODUCT_ACTION
// export const GET_PRODUCT_REQUEST = 'GET_PRODUCT_REQUEST';
// export const GET_PRODUCT_SUCCESS = 'GET_PRODUCT_SUCCESS';
// export const GET_PRODUCT_FAILURE = 'GET_PRODUCT_FAILURE';
