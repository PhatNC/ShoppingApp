import React, { Component } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';


import { Icon, Button, Container, Header, Content, Left } from 'native-base';

export default class Contact extends Component {
    render() {
        return (
            <Container style={{ backgroundColor: '#69F0AE' }}>
                <Text>
                    Contact Component
                </Text>
            </Container>
        )
    }
}
